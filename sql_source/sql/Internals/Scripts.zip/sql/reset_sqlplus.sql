-------------------------------------------------------------------------------
--
-- Script:	reset_sqlplus.sql
-- Purpose:	to reset sqlplus settings
--
-- Copyright:	(c) 1998 Ixora Pty Ltd
-- Author:	Steve Adams
--
-------------------------------------------------------------------------------

clear breaks
clear columns
clear computes
set feedback off
set verify off

