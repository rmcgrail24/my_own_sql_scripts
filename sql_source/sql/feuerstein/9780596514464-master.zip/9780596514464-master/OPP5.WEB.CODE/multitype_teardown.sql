
DROP TABLE customer_staging;
DROP PACKAGE customer_pkg;
DROP TABLE addresses;
DROP TABLE customers;
DROP TYPE address_detail_ot;
DROP TYPE customer_detail_ot;
DROP TYPE customer_ntt;
DROP TYPE customer_ot;
DROP TYPE customer_address_ntt;
DROP TYPE customer_address_ot;



/*======================================================================
| Supplement to the fifth edition of Oracle PL/SQL Programming by Steven
| Feuerstein with Bill Pribyl, Copyright (c) 1997-2009 O'Reilly Media, Inc. 
| To submit corrections or find more code samples visit
| http://oreilly.com/catalog/9780596514464/
*/


