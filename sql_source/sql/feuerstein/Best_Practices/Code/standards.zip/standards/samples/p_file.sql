<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<LINK rel="stylesheet" type="text/css" href="../../../../doc_style.css">
</head>
<body>
<table width=650 cellspacing=0>
<tr><td>
<PRE class=code>CREATE OR REPLACE PACKAGE DQLIB.p_file
IS

   /*
   Comment:
   Provides simple api for writing lines to a file. The
   procedures should be called in order set_path, write,
   and then close. After close is called calling set_path 
   again with the same file will overwrite the existing file.

   Usage:
   SQL&gt;begin
     2 p_file.set_path;
     3 p_file.write('line one text');
     4 p_file.write('line two text');
     5 p_file.close;
     6 end;
     7 /

   PL/SQL Procedure completed successfully

   SQL&gt;exit

   $cat /tmp/p_file.out
   line one text
   line two text
   $

   Assumptions/Limitaions:
   The directory used in con_default_path must match a path in
   the init.ora parameter for utl_file directories

   History:
   11/07/00 mwm initial coding 
   */
   
   --Permits call to set_path without specifying any
   --path or file 
   con_default_path varchar2(50) := '/tmp/p_file.out';


   --Specify full path and file name to write to if different
   --that the default. Make sure that the directory is set in 
   --the init.ora file
   PROCEDURE set_path (p_full_path IN VARCHAR2 := con_default_path);

 
   --Write the value to the file.  Adds a line return at the end 
   --of the value.
   PROCEDURE write (p_value IN VARCHAR2);
   

   --Closes the file 
   PROCEDURE close;

END p_file;
/

CREATE OR REPLACE PACKAGE BODY dqlib.p_file
IS

   --Will change if moving from Unix to Windows
   con_separator VARCHAR2 (1) := '/';

   pv_full_path VARCHAR2 (300); --Path and file name combined
   pv_path VARCHAR2 (200);      --Path only, no / at the end
   pv_file_name VARCHAR2 (100); --File name only

   pv_handle UTL_FILE.file_type; --Reference to file 

   --Return path portion of full path and file name
   --do not include a trailing separator
   FUNCTION path
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN 
      (SUBSTR (pv_full_path, 1, INSTR (pv_full_path, con_separator, -1) - 1));
   END path;


   --Return the file name portion of the full path and file name
   FUNCTION file_name
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN 
      (SUBSTR (pv_full_path, INSTR (pv_full_path, con_separator, -1) + 1));
   END file_name;


   PROCEDURE set_path (p_full_path IN VARCHAR2 := p_file.con_default_path)
   IS
   BEGIN
      pv_full_path := p_full_path;
      pv_path := path;
      pv_file_name := file_name;
      pv_handle := UTL_FILE.fopen (pv_path, pv_file_name, 'w');
   END set_path;

   
   PROCEDURE write (p_value IN VARCHAR2)
   IS
   BEGIN
      UTL_FILE.put_line (pv_handle, p_value);
   END write;


   PROCEDURE close
   IS
   BEGIN
      UTL_FILE.fclose (pv_handle);
   END close;

END p_file;
/</PRE>
</td></tr>
</table>
</body>
</html>