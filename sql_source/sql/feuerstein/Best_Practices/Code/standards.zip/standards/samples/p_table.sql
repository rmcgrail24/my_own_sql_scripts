<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<LINK rel="stylesheet" type="text/css" href="../../../../doc_style.css">
</head>
<table border=0 cellspacing=0 width=650>
<tr><td>
<PRE class=code>CREATE OR REPLACE PACKAGE DQLIB.p_table
IS

   -- Comment:
   -- Generate common sql statements for a table
   --
   -- Usage:
   -- SQL&gt;set serveroutput on size 10000
   -- SQL&gt;spool /tmp/emp.sql
   -- SQL&gt;exec p_table.generate_insert ('scott','emp');
   -- INSERT INTO dqlib.emp (
   --    empno,
   --    ename,
   --    job,
   --    mgr,
   --    hiredate,
   --    sal,
   --    comm,
   --    deptno
   -- )
   -- VALUES (
   --    /* empno    NUMBER (4,0) */,
   --    /* ename    VARCHAR2 (10) */,
   --    /* job      VARCHAR2 (20) */,
   --    /* mgr      NUMBER (4,0) */,
   --    /* hiredate DATE */,
   --    /* sal      NUMBER (7,2) */,
   --    /* comm     NUMBER (7,2) */,
   --    /* deptno   NUMBER (2,0) */
   -- );
   --
   -- PL/SQL Procedure Completed Successfully
   --
   -- Assumptions/Limitations:
   -- Procedures will not work with tables or columns created using
   -- quoted identifiers and mixed case or special charaters.
   --
   -- History:
   -- 11/08/00 mwm Initial Coding

   --Generate an insert statement can be used to add a row to the
   --table. The statement will contains a comment in place of each
   --value to indicate the data type and size for that column.
   PROCEDURE generate_insert (p_owner IN VARCHAR2,  p_name IN VARCHAR2);

END p_table;
/


CREATE OR REPLACE PACKAGE BODY DQLIB.p_table
IS

   pv_owner   VARCHAR2 (30); --The owner of the table
   pv_name    VARCHAR2 (30); --The name of the table

   CURSOR pc_columns
   IS
      SELECT column_name, data_type, data_length, data_precision, data_scale
        FROM dba_tab_columns
       WHERE owner = pv_owner
         AND table_name = pv_name;

   --Return the number of columns in the table
   --This is used to determine if a comma needs to be printed
   --after the column name.
   FUNCTION column_count
      RETURN INT
   IS
      v_count   INT := 0;

   BEGIN
      SELECT count (*)
        INTO v_count
        FROM dba_tab_columns
       WHERE owner = pv_owner
         AND table_name = pv_name;

      RETURN v_count;

   END column_count;


   --Return the number of characters in the name of the
   --column that has the longest name
   FUNCTION max_width
      RETURN INT
   IS
      v_max   INT;
   
   BEGIN
      SELECT max (length (column_name))
        INTO v_max
        FROM dba_tab_columns
       WHERE owner = pv_owner
         AND table_name = pv_name;
   
      RETURN v_max;
   
   END max_width;


   PROCEDURE generate_insert (p_owner IN VARCHAR2, p_name IN VARCHAR2)
   IS
      v_count    INT             := 0; --Number of columns in table
      v_col_id   INT             := 0; --Index of current column in loop
      v_sql      VARCHAR2 (20000);     --Line of insert statement 
      v_max_width int;                 --Length of widest column name

   BEGIN
      pv_owner := upper(p_owner);
      pv_name := upper(p_name);

      --Table and column names are printed in lower case as a formatting
      --preference only
      v_sql := 'INSERT INTO ' || lower(pv_owner) || '.' || lower(pv_name) || ' (';
      dbms_output.put_line (v_sql);
      v_max_width := max_width;
      v_count := column_count;
      FOR vrt_col IN pc_columns LOOP
         v_col_id := v_col_id + 1;
         --Add 3 space indentation for column list
         v_sql := lower('   '||vrt_col.column_name);

         --Commas are needed on all but the last column
         IF v_col_id &lt; v_count THEN
            v_sql := v_sql || ',';
         END IF;
         dbms_output.put_line (v_sql);

      END LOOP;

      dbms_output.put_line (')');
      dbms_output.put_line ('VALUES (');

      v_col_id := 0;
      FOR vrt_col IN pc_columns LOOP
         v_col_id := v_col_id + 1;
         --Add same indentation as column list and pad to widest column
         --so data types will align
         v_sql := '   /* ' || rpad(lower(vrt_col.column_name),v_max_width) || ' ' || vrt_col.data_type;

         IF vrt_col.data_type IN ('VARCHAR2', 'CHAR') THEN
            v_sql := v_sql || ' (' || vrt_col.data_length || ') */';
         END IF;

         IF     vrt_col.data_type = 'NUMBER'
            AND vrt_col.data_precision IS NOT NULL THEN
            v_sql :=
               v_sql || ' (' || vrt_col.data_precision || ','
                             || vrt_col.data_scale || ') */';

         ELSIF (vrt_col.data_type = 'NUMBER'
            AND vrt_col.data_precision IS NULL)
             OR vrt_col.data_type IN ('FLOAT','DATE') THEN
            v_sql := v_sql || ' */';

         END IF;

         --Commas are needed on all but the last column
         IF v_col_id &lt; v_count THEN
            v_sql := v_sql || ',';
         END IF;
         dbms_output.put_line (v_sql);

      END LOOP;
      dbms_output.put_line (');');

   END generate_insert;

END p_table;
</PRE>
</td></tr>
</table>
