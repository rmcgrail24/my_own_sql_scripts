INSERT INTO ledger VALUES  ('Salary', 100000)
/
INSERT INTO ledger VALUES  ('Capital_gains', 15000)
/
INSERT INTO ledger VALUES  ('Net', 0)
/
INSERT INTO ledger VALUES  ('Tax', 0)
/
INSERT INTO ledger VALUES  ('Interest', 0)
/
