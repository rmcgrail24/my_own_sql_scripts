CREATE TABLE dollar_conv(country VARCHAR2(30), exchange_rate NUMBER)
/
