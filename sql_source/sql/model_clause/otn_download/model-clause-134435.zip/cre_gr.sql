CREATE TABLE growth_rate(country     VARCHAR2(30), 
                         year        NUMBER, 
                         growth_rate NUMBER)
/
