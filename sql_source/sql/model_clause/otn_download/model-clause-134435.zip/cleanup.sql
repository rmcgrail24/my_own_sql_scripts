DROP VIEW sales_view;

DROP TABLE dollar_conv;

DROP TABLE growth_rate;

DROP TABLE ledger;
