SELECT COUNT(*) FROM sales_view
/
