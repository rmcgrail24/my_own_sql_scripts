INSERT INTO dollar_conv VALUES('Canada', 0.75)
/ 
INSERT INTO dollar_conv VALUES('Brazil', 0.14)
/
