INSERT INTO growth_rate VALUES('Brazil', 2002, 2.5)
/
INSERT INTO growth_rate VALUES('Brazil', 2003, 5)
/
INSERT INTO growth_rate VALUES('Canada', 2002, 3)
/
INSERT INTO growth_rate VALUES('Canada', 2003, 2.5)
/
